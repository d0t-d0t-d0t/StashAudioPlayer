This plugin adds an audio-only toggle button and support for audio files in the Stash player through hls transcoder.
